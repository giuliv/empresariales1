package com.isil.mysql;

import com.isil.dao.ReservaDAO;

public class MySQLVehiculoDAO {


}
