package com.isil.dao;

import com.isil.model.Pasajero;

public interface PasajeroDAO extends DAO <Pasajero,Integer> {
}
