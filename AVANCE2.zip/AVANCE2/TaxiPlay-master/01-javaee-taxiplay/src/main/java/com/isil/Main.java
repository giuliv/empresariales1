package com.isil;

import com.isil.dao.ChoferDAO;
import com.isil.dao.ReservaDAO;
import com.isil.model.Chofer;
import com.isil.model.Pasajero;
import com.isil.model.Reserva;
import com.isil.mysql.MySQLChoferDAO;
import com.isil.mysql.MySQLPasajeroDAO;
import com.isil.mysql.MySQLReservaDAO;

import java.util.List;

public class Main {

    public static void main(String[] args) {

        // CHOFER //

        MySQLChoferDAO choferDAO = new MySQLChoferDAO();
        List<Chofer> choferes = choferDAO.obtenerTodos();


         /*prueba insertar registro
        Chofer ch = new Chofer("Joaquín","Perez","29837644","945673456","joaquin@gmail.com");
        choferDAO.insertar(ch);*/

        /*prueba listar uno
        System.out.println(choferDAO.obtenerUno(1));*/

        /*prueba listar todos
        choferes.stream().forEach(u -> System.out.println("user = " + u));*/

        // PASAJERO //

        MySQLPasajeroDAO pasajeroDAO = new MySQLPasajeroDAO();
        List<Pasajero> pasajeros = pasajeroDAO.obtenerTodos();
        System.out.println("pasajeros = " + pasajeros);

         /*prueba insertar registro
        Pasajero pas = new Pasajero("Ana","Gomez","29837644","945673456","joaquin@gmail.com");
        choferDAO.insertar(ch);*/

        /*prueba listar uno
        System.out.println(choferDAO.obtenerUno(1));*/

        /*prueba listar todos
        choferes.stream().forEach(u -> System.out.println("user = " + u));*/


        //Reserva

        MySQLReservaDAO reservaDAO = new MySQLReservaDAO();
        List<Reserva> reservas = reservaDAO.obtenerTodos();
        System.out.println("reservas : "+ reservas);

        /*
        //insertando reserva
        Reserva reserva = new Reserva(1,1,"Avenida Benavides 217",
                "Avenida Arequipa 1015","2019-01-19","2019-01-19.", 54543.646,465456.77, 0.0, 5.1, 4.9, 8.0,"Efectivo");
        reservaDAO.insertar(reserva);

        //listando uno

        System.out.println(reservaDAO.obtenerUno(1));

        //listar todos
        reservas.stream().forEach(u -> System.out.println("reservas = "+ u));

*/





    }
}
